

public class Snorlax extends Pokemon{
	public Snorlax(String name, float weight, float stepLength){
		super(name, weight, stepLength, 1f, new String[] {"normal"});
	}
}
